<template>
  <div class="container">
    <v-container>
      <h1>การบ้าน/งานที่ได้รับมอบหมาย</h1>
      เลือกรายวิชา
      <v-row>
        <v-col cols="12" md="4">
          <v-select
            v-model="subject"
            :items="items"
            label="--เลือกหัวข้อ--"
            solo
          ></v-select> </v-col
        ><v-col cols="12" md="4"
          ><v-text-field v-model="work" label="ชื่องาน" outlined></v-text-field>
        </v-col>
      </v-row>

      <v-btn color="success" class="mr-4" @click="addTodo()">เพิ่ม</v-btn>
      <v-container>
        <h1>รายวิชาที่เพิ่ม</h1>
        <v-list dense>
          <v-list-item-group v-model="selectedItem" color="primary">
            <v-list-item v-for="(item, i) in additems" :key="i">
              <v-list-item-icon>
                <v-icon v-text="item.icon"></v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title v-text="item.text"></v-list-item-title>
              </v-list-item-content>

              <v-btn
                class="mx-2"
                fab
                dark
                small
                color="bg-danger"
                @click="deleteTodo(i)"
              >
                <v-icon dark>mdi-minus</v-icon>
              </v-btn>
            </v-list-item>
          </v-list-item-group>
        </v-list>
      </v-container>
    </v-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      subject: "",
      work: "",
      items: ["วิชา Web", " วิชา SA", " วิชา ML", "วิชา อื่นๆ"],
      selectedItem: 1,
      additems: [
        { text: "วิชา Web Assignment500" },
        { text: "วิชา SA Assignment1" },
        { text: "วิชา ML ออกแบบ" },
        { text: "วิชา Web Assignment501" },
      ],
    };
  },
  methods: {
    addTodo() {
      // console.log(this.subject+this.work);
      this.additems.push({ text: this.subject + " " + this.work });
    },
    deleteTodo(index) {
      this.additems.splice(index, 1);
    },
  },
};
</script>
<style>
h1 {
  color: darkblue;
}
</style>
